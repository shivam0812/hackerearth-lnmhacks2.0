<?php  
    saveAllDetails()
?>